#ifndef __FILADIN_H__
#define __FILADIN_H__

typedef struct pessoa {
    char nome[30];
    char cpf[30];
    int idade;
    
}Pessoa;
typedef struct no{
  Pessoa *pessoa;
  struct no *prox;
}No;

typedef struct fila{
  No *inicio;
  No *fim;
  int tam;
}Fila;

void scanfpessoa(Pessoa *p);
void cria(Fila *f);
int vazia(Fila *f);
int tamanho(Fila *f);
int entrar(Fila *f);
int sair(Fila *f);
void exibir(Fila *f);

#endif



