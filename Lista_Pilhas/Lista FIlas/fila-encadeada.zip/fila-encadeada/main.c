#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "filadin.h"
#include "filadin.h"


int main(void) {
    Fila *f = malloc(sizeof(Fila));
    cria(f);
    int resposta;
    while (1){
            printf("\n");
            printf("Editor de Fila\n");
            printf("--------------------------------\n");
            printf("1 – EXIBIR FILA\n");
            printf("2 – ENTRAR NA FILA\n");
            printf("3 – SAIR DA FILA\n");
            printf("4 – PRIMEIRO DA FILA\n");
            printf("5 – ULTIMO DA FILA\n");
            printf("6 – QUANTIDADE DE PESSOAS NA FILA\n");
            printf("7 – SAIR\n");
            printf("\n");
            printf("Digite a opção: ");scanf("%d", &resposta);
            
            switch (resposta) {
                    
                case 1:exibir(f);break;
                case 2:entrar(f);break;
                case 3:sair(f);break;
                case 4:
                    printf("Nome: %s\n", f->inicio->pessoa->nome);
                    printf("Cpf: %s\n", f->inicio->pessoa->cpf);
                    printf("Idade: %d\n", f->inicio->pessoa->idade);
                    break;
                case 5:
                    printf("Nome: %s\n", f->fim->pessoa->nome);
                    printf("Cpf: %s\n", f->fim->pessoa->cpf);
                    printf("Idade: %d\n", f->fim->pessoa->idade);
                    break;
                case 6:
                    printf("Quantidade de pessoas na fila: %d", tamanho(f));
                    break;
                case 7:
                    return 0;
                default:
                    break;
            }
    }
  return 0;
}
